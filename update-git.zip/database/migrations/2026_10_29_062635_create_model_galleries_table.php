<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
    Schema::create('model_galleries', function (Blueprint $table) {
        $table->id();
        $table->foreignId('product_model_id')->constrained('product_models')->cascadeOnDelete();
        $table->string('image_path');
        $table->integer('sort_order')->default(0);
        $table->timestamps();
    });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::dropIfExists('model_galleries');
    }
};
