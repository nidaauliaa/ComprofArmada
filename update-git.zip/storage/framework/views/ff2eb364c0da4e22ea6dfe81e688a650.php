<article class="news-card">
    <div class="news-date"><?php echo e($n->dateLabel()); ?></div>

    <a class="news-img" href="<?php echo e(route('news.show', $n->slug)); ?>" tabindex="-1" aria-hidden="true">
        <?php if($n->thumbnail_url): ?>
            <img src="<?php echo e($n->thumbnail_url); ?>" alt="" loading="lazy" onerror="this.remove()">
        <?php endif; ?>
    </a>

    <div class="news-body">
        <h3><?php echo e($n->tr('title')); ?></h3>
        <p><?php echo e($n->summary(160) ?: __('site.news_fallback')); ?></p>
        <a class="news-more" href="<?php echo e(route('news.show', $n->slug)); ?>"><?php echo e(__('site.read_more')); ?> <span>→</span></a>
    </div>
</article>
<?php /**PATH E:\newarmada\companyprofile\ComprofArmada\resources\views/news/_card.blade.php ENDPATH**/ ?>