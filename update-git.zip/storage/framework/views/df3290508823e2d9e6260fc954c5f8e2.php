
<?php $brand = $brand ?? 'img'; $cur = $cur ?? ''; ?>
<header id="siteHeader">
  <div class="wrap nav">
    <?php if($brand === 'logo'): ?>
      <a class="logo" href="<?php echo e(url('/')); ?>"><span class="logo-icon"></span>NEW ARMADA</a>
    <?php else: ?>
      <a class="brand" href="<?php echo e(url('/')); ?>" aria-label="New Armada">
        <img src="<?php echo e(asset('storage/images/logo-newarmada.png')); ?>" alt="New Armada" width="41" height="52">
        <span class="brand-text">NEW ARMADA</span>
      </a>
    <?php endif; ?>
    <nav>
      <a href="<?php echo e(url('/')); ?>#produk" class="<?php echo \Illuminate\Support\Arr::toCssClasses(['cur' => $cur === 'products']); ?>"><?php echo e(__('site.products')); ?></a>
      <a href="<?php echo e(url('/')); ?>#unit"><?php echo e(__('site.business_unit')); ?></a>
      <a href="<?php echo e(route('news.index')); ?>" class="<?php echo \Illuminate\Support\Arr::toCssClasses(['cur' => $cur === 'news']); ?>"><?php echo e(__('site.news')); ?></a>
      <a href="<?php echo e(url('/')); ?>#plant"><?php echo e(__('site.location')); ?></a>
      <button type="button" class="lang icon" data-search-open aria-label="<?php echo e(__('site.search')); ?>"><svg viewBox="0 0 24 24"><circle cx="11" cy="11" r="7"/><path d="M20 20l-3.5-3.5"/></svg></button>
      <?php if (isset($component)) { $__componentOriginal0833810ddf751288ebafc69f0fa98b01 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal0833810ddf751288ebafc69f0fa98b01 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.lang-switcher','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('lang-switcher'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal0833810ddf751288ebafc69f0fa98b01)): ?>
<?php $attributes = $__attributesOriginal0833810ddf751288ebafc69f0fa98b01; ?>
<?php unset($__attributesOriginal0833810ddf751288ebafc69f0fa98b01); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal0833810ddf751288ebafc69f0fa98b01)): ?>
<?php $component = $__componentOriginal0833810ddf751288ebafc69f0fa98b01; ?>
<?php unset($__componentOriginal0833810ddf751288ebafc69f0fa98b01); ?>
<?php endif; ?>
      <a class="btn btn-red" href="<?php echo e(url('/kontak')); ?>"><?php echo e(__('site.contact_us')); ?></a>
    </nav>
  </div>
</header>
<?php /**PATH E:\newarmada\companyprofile\ComprofArmada\resources\views/partials/public-header.blade.php ENDPATH**/ ?>