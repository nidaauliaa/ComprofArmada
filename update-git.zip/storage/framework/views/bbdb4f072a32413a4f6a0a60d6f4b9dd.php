<?php $__env->startSection('title', 'Lokasi Plant'); ?>
<?php $__env->startSection('page_icon', 'pin'); ?>
<?php $__env->startSection('page_title', 'Lokasi Plant'); ?>

<?php $__env->startPush('styles'); ?>

<link rel="stylesheet" href="<?php echo e(asset('css/admin-news.css')); ?>?v=<?php echo e(@filemtime(public_path('css/admin-news.css'))); ?>">
<?php $__env->stopPush(); ?>

<?php $__env->startSection('content'); ?>
    <?php if($errors->any()): ?>
        <div class="alert-error">
            <b>Lokasi belum tersimpan:</b>
            <ul><?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $e): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><li><?php echo e($e); ?></li><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?></ul>
        </div>
    <?php endif; ?>

    <div class="ph">
        <div>
            <h1>Lokasi Plant</h1>
            <p class="mu">Setiap lokasi menjadi pin di peta pada bagian Lokasi Plant di website.</p>
        </div>
        <button type="button" class="b" id="plAdd"><svg class="i"><use href="#i-plus"/></svg> Tambah lokasi</button>
    </div>

    <?php $__empty_1 = true; $__currentLoopData = $plants; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
        <div class="row">
            <span class="ri"><svg class="i"><use href="#i-pin"/></svg></span>

            <div class="rt">
                <b><?php echo e($p->name); ?></b>
                <small><?php echo e($p->address); ?></small>
            </div>

            <label class="sw" title="Tayang di website">
                <input type="checkbox" class="js-toggle" data-url="<?php echo e(route('admin.plants.toggle', $p)); ?>" <?php echo e($p->is_active ? 'checked' : ''); ?>><i></i>
            </label>

            <button type="button" class="b o s js-edit" data-id="<?php echo e($p->id); ?>"><svg class="i"><use href="#i-edit"/></svg> Ubah</button>

            <form method="POST" action="<?php echo e(route('admin.plants.destroy', $p)); ?>" class="js-del" style="margin:0">
                <?php echo csrf_field(); ?> <?php echo method_field('DELETE'); ?>
                <button type="button" class="b o s js-del-btn"><svg class="i"><use href="#i-trash"/></svg> Hapus</button>
            </form>
        </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
        <div class="emp">Belum ada lokasi. Klik “Tambah lokasi” untuk membuat.</div>
    <?php endif; ?>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('modals'); ?>
<div class="ov" id="pOv" hidden></div>


<div class="dr" id="pDr">
    <form id="pForm" method="POST" action="<?php echo e(route('admin.plants.store')); ?>" novalidate>
        <?php echo csrf_field(); ?>
        <input type="hidden" name="_method" value="PUT" id="pMethod" disabled>

        <div class="dh">
            <b id="pTitle">Tambah lokasi</b>
            <button type="button" class="b o s" data-close aria-label="Tutup"><svg class="i"><use href="#i-x"/></svg></button>
        </div>

        <div class="db">
            <label>Nama plant <em>*</em><input name="name" maxlength="100" autocomplete="off" placeholder="Contoh: Magelang (HQ)"></label>
            <?php if (isset($component)) { $__componentOriginal218d1539083e8b34d7b42c5a3d5c63f4 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal218d1539083e8b34d7b42c5a3d5c63f4 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.lang-tabs','data' => ['name' => 'name','mode' => 'suffix','idBase' => 'pName','label' => 'Terjemahan nama plant','only' => ['en','zh']]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('lang-tabs'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['name' => 'name','mode' => 'suffix','id-base' => 'pName','label' => 'Terjemahan nama plant','only' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute(['en','zh'])]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal218d1539083e8b34d7b42c5a3d5c63f4)): ?>
<?php $attributes = $__attributesOriginal218d1539083e8b34d7b42c5a3d5c63f4; ?>
<?php unset($__attributesOriginal218d1539083e8b34d7b42c5a3d5c63f4); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal218d1539083e8b34d7b42c5a3d5c63f4)): ?>
<?php $component = $__componentOriginal218d1539083e8b34d7b42c5a3d5c63f4; ?>
<?php unset($__componentOriginal218d1539083e8b34d7b42c5a3d5c63f4); ?>
<?php endif; ?>
            <label>Alamat <em>*</em><textarea name="address" rows="3" maxlength="500" placeholder="Alamat lengkap"></textarea></label>
            <?php if (isset($component)) { $__componentOriginal218d1539083e8b34d7b42c5a3d5c63f4 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal218d1539083e8b34d7b42c5a3d5c63f4 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.lang-tabs','data' => ['name' => 'address','mode' => 'suffix','idBase' => 'pAddr','type' => 'textarea','rows' => 2,'label' => 'Terjemahan alamat','only' => ['en','zh'],'help' => 'Kosong = website memakai Bahasa Indonesia.']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('lang-tabs'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['name' => 'address','mode' => 'suffix','id-base' => 'pAddr','type' => 'textarea','rows' => 2,'label' => 'Terjemahan alamat','only' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute(['en','zh']),'help' => 'Kosong = website memakai Bahasa Indonesia.']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal218d1539083e8b34d7b42c5a3d5c63f4)): ?>
<?php $attributes = $__attributesOriginal218d1539083e8b34d7b42c5a3d5c63f4; ?>
<?php unset($__attributesOriginal218d1539083e8b34d7b42c5a3d5c63f4); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal218d1539083e8b34d7b42c5a3d5c63f4)): ?>
<?php $component = $__componentOriginal218d1539083e8b34d7b42c5a3d5c63f4; ?>
<?php unset($__componentOriginal218d1539083e8b34d7b42c5a3d5c63f4); ?>
<?php endif; ?>
            <label>Telepon <small>opsional</small><input name="phone" maxlength="50" autocomplete="off" placeholder="Contoh: (0293) 364371"></label>

            <label>Link Google Maps <small>untuk tombol “Buka di Google Maps” di website</small>
                <input type="url" name="maps_url" maxlength="500" autocomplete="off" placeholder="https://maps.app.goo.gl/...">
            </label>
            <p class="mu" style="margin:-6px 0 14px;font-size:13px">
                Cari lokasinya di Google Maps, klik <b>Bagikan</b>, lalu <b>Salin link</b> dan tempel di sini.
            </p>

            <div class="g2">
                <label>Latitude <em>*</em><input name="lat" id="pLat" inputmode="decimal" autocomplete="off" placeholder="-7.4950"></label>
                <label>Longitude <em>*</em><input name="lng" id="pLng" inputmode="decimal" autocomplete="off" placeholder="110.2200"></label>
            </div>
            <p class="mu" style="margin:-6px 0 14px;font-size:13px">
                Cara mengisi: buka Google Maps, klik kanan di titik lokasi, lalu klik angka koordinat paling atas untuk menyalinnya.
                Tempel (paste) ke kolom Latitude, kolom Longitude terisi otomatis.
            </p>

            <label>Urutan tampil <small>angka kecil tampil lebih atas</small><input type="number" name="sort_order" min="0" max="9999"></label>

            <label class="ck"><input type="checkbox" name="is_active" value="1" checked> Tayangkan di website</label>
        </div>

        <div class="df">
            <button type="submit" class="b" id="pSave">Simpan</button>
            <button type="button" class="b o" data-close>Batal</button>
        </div>
    </form>
</div>
<div id="tst" hidden></div>
<?php $__env->stopPush(); ?>

<?php $__env->startPush('scripts'); ?>
<script>
    window.PLANT_CFG = {
        store: <?php echo json_encode(route('admin.plants.store'), 15, 512) ?>,
        next:  <?php echo json_encode($nextOrder, 15, 512) ?>,
        data:  <?php echo json_encode((object) $editData, 15, 512) ?>
    };
</script>
<script src="<?php echo e(asset('js/admin-plants.js')); ?>?v=<?php echo e(@filemtime(public_path('js/admin-plants.js'))); ?>"></script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.admin', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH E:\newarmada\companyprofile\ComprofArmada\resources\views/admin/plants/index.blade.php ENDPATH**/ ?>