<?php $__env->startSection('title', 'Beranda'); ?>
<?php $__env->startSection('page_icon', 'home'); ?>
<?php $__env->startSection('page_title', 'Beranda'); ?>


<?php $__env->startSection('content'); ?>
<?php
    $has = fn ($route) => \Illuminate\Support\Facades\Route::has($route);

    $bannerCount   = \App\Models\Banner::where('is_active', 1)->count();
    $newsCount     = \App\Models\News::where('is_active', 1)->count();
    $newsNoThumb   = \App\Models\News::where('is_active', 1)->whereNull('thumbnail_path')->count();
    $plantCount    = \App\Models\Plant::where('is_active', 1)->count();
    $newsNoEnglish = \App\Models\News::where('is_active', 1)->where(function ($q) {
        $q->whereNull('title->en')->orWhere('title->en', '');
    })->count();
?>
    <h1>Selamat datang</h1>
    <p class="mu">Ubah konten di sini, website langsung ikut berubah.</p>

    <div class="qa">
        <a href="<?php echo e($has('admin.banners.index') ? route('admin.banners.index') : '#'); ?>"><svg class="i"><use href="#i-image"/></svg>Ubah banner</a>
        <a href="#"><svg class="i"><use href="#i-bus"/></svg>Kelola produk</a>
        <a href="<?php echo e($has('admin.news.index') ? route('admin.news.index', ['tambah' => 1]) : '#'); ?>"><svg class="i"><use href="#i-news"/></svg>Tulis berita</a>
        <a href="<?php echo e($has('admin.plants.index') ? route('admin.plants.index') : '#'); ?>"><svg class="i"><use href="#i-pin"/></svg>Atur lokasi</a>
    </div>

    <div class="card">
        <h3 style="margin-top:0">Ringkasan</h3>
        <div class="st">
            <div><b><?php echo e($bannerCount); ?></b>Banner tayang</div>
            
            <div><b>20</b>Model tayang</div>
            <div><b><?php echo e($newsCount); ?></b>Berita tayang</div>
            <div><b><?php echo e($plantCount); ?></b>Lokasi tayang</div>
        </div>
    </div>

    <div class="card">
        <h3 style="margin-top:0">Perlu dilengkapi</h3>
        <?php if($newsNoThumb === 0 && $newsNoEnglish === 0): ?>
            <p><span class="bdg">✓</span> Semua konten sudah lengkap.</p>
        <?php endif; ?>
        <?php if($newsNoThumb > 0): ?>
            <p><span class="bdg" style="background:#ffedd5;color:#9a3412">!</span> <?php echo e($newsNoThumb); ?> berita belum punya thumbnail
                <?php if($has('admin.news.index')): ?> · <a href="<?php echo e(route('admin.news.index')); ?>" style="color:var(--pr);font-weight:600">Lengkapi</a><?php endif; ?></p>
        <?php endif; ?>
        <?php if($newsNoEnglish > 0): ?>
            <p><span class="bdg" style="background:#ffedd5;color:#9a3412">!</span> <?php echo e($newsNoEnglish); ?> berita belum ada judul bahasa Inggris
                <?php if($has('admin.news.index')): ?> · <a href="<?php echo e(route('admin.news.index')); ?>" style="color:var(--pr);font-weight:600">Lengkapi</a><?php endif; ?></p>
        <?php endif; ?>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH E:\newarmada\companyprofile\ComprofArmada\resources\views/dashboard.blade.php ENDPATH**/ ?>