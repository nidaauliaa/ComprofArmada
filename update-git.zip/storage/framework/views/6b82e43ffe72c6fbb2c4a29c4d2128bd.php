<?php
    $menu = [
        ['route' => 'dashboard',            'active' => 'dashboard',         'icon' => 'home',  'label' => 'Beranda'],
        ['route' => 'admin.banners.index',  'active' => 'admin.banners.*',   'icon' => 'image', 'label' => 'Banner'],
        ['route' => 'admin.products.index', 'active' => 'admin.products.*',  'icon' => 'bus',   'label' => 'Produk'],
        ['route' => 'admin.news.index',     'active' => 'admin.news.*',      'icon' => 'news',  'label' => 'Berita & Event'],
        ['route' => 'admin.plants.index',   'active' => 'admin.plants.*',    'icon' => 'pin',   'label' => 'Lokasi Plant'],
        ['route' => 'admin.social.index',   'active' => 'admin.social.*',    'icon' => 'ig',    'label' => 'Instagram'],
        ['route' => 'admin.settings.index', 'active' => 'admin.settings.*',  'icon' => 'gear',  'label' => 'Pengaturan Situs'],
        ['route' => 'admin.account.index',  'active' => 'admin.account.*',   'icon' => 'user',  'label' => 'Akun'],
    ];
?>
<aside>
    <div>
        <div class="al"><span class="lgm"></span><span class="lt">NEW<b>ARMADA</b></span></div>
        <nav>
            <?php $__currentLoopData = $menu; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $m): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <a href="<?php echo e(\Illuminate\Support\Facades\Route::has($m['route']) ? route($m['route']) : '#'); ?>"
                   class="<?php echo e(request()->routeIs($m['active']) ? 'on' : ''); ?>"
                   title="<?php echo e($m['label']); ?>">
                    <svg class="i"><use href="#i-<?php echo e($m['icon']); ?>"/></svg><span><?php echo e($m['label']); ?></span>
                </a>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </nav>
    </div>
</aside>
<?php /**PATH E:\newarmada\companyprofile\ComprofArmada\resources\views/layouts/admin-sidebar.blade.php ENDPATH**/ ?>