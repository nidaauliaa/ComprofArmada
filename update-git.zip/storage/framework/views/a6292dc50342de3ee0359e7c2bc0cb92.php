<div class="search-pop" id="searchPop" data-suggest="<?php echo e(route('search.suggest')); ?>" hidden>
  <div class="search-box">
    <form action="<?php echo e(route('search')); ?>" method="get" role="search">
      <input type="search" name="q" id="searchInput" placeholder="<?php echo e(__('site.search_placeholder')); ?>" autocomplete="off" minlength="2" required>
      <button class="btn" type="submit"><?php echo e(__('site.search')); ?></button>
    </form>
    <ul class="sug" id="sugList"></ul>
  </div>
</div>
<?php /**PATH E:\newarmada\companyprofile\ComprofArmada\resources\views/partials/search-overlay.blade.php ENDPATH**/ ?>