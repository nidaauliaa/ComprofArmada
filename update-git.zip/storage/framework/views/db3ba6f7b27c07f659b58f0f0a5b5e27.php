
<?php $attributes ??= new \Illuminate\View\ComponentAttributeBag;

$__newAttributes = [];
$__propNames = \Illuminate\View\ComponentAttributeBag::extractPropNames((['name', 'label' => '', 'type' => 'text', 'values' => [], 'mode' => 'array', 'rows' => 3, 'help' => null, 'only' => null, 'idBase' => null]));

foreach ($attributes->all() as $__key => $__value) {
    if (in_array($__key, $__propNames)) {
        $$__key = $$__key ?? $__value;
    } else {
        $__newAttributes[$__key] = $__value;
    }
}

$attributes = new \Illuminate\View\ComponentAttributeBag($__newAttributes);

unset($__propNames);
unset($__newAttributes);

foreach (array_filter((['name', 'label' => '', 'type' => 'text', 'values' => [], 'mode' => 'array', 'rows' => 3, 'help' => null, 'only' => null, 'idBase' => null]), 'is_string', ARRAY_FILTER_USE_KEY) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
}

$__defined_vars = get_defined_vars();

foreach ($attributes->all() as $__key => $__value) {
    if (array_key_exists($__key, $__defined_vars)) unset($$__key);
}

unset($__defined_vars, $__key, $__value); ?>
<?php
    $locales = config('site.locales');
    if (is_array($only)) { $locales = array_intersect_key($locales, array_flip($only)); }
    $elId = fn ($c) => $idBase ? ($c === 'id' ? $idBase : $idBase.ucfirst($c)) : null;
    $fieldName = fn ($c) => $mode === 'suffix' ? ($c === 'id' ? $name : $name.'_'.$c) : $name.'['.$c.']';
    $oldKey = fn ($c) => $mode === 'suffix' ? ($c === 'id' ? $name : $name.'_'.$c) : $name.'.'.$c;
    $short = fn ($c) => $c === 'zh' ? '中文' : strtoupper($c);
?>
<div class="lt" data-lt>
    <?php if($label): ?><div class="lt-label"><?php echo e($label); ?></div><?php endif; ?>
    <div class="lt-bar" role="tablist">
        <?php $__currentLoopData = $locales; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $code => $n): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <button type="button" role="tab" class="lt-tab <?php echo e($loop->first ? 'on' : ''); ?>" data-lt-tab="<?php echo e($code); ?>"><?php echo e($short($code)); ?><i class="lt-dot" hidden></i></button>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
    <?php $__currentLoopData = $locales; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $code => $n): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <?php $val = old($oldKey($code), $values[$code] ?? ''); ?>
        <div class="lt-pane <?php echo e($loop->first ? 'on' : ''); ?>" data-lt-pane="<?php echo e($code); ?>">
            <?php if($type === 'textarea'): ?>
                <textarea name="<?php echo e($fieldName($code)); ?>" <?php if($elId($code)): ?> id="<?php echo e($elId($code)); ?>" <?php endif; ?> rows="<?php echo e($rows); ?>" data-lt-input><?php echo e($val); ?></textarea>
            <?php else: ?>
                <input type="text" name="<?php echo e($fieldName($code)); ?>" <?php if($elId($code)): ?> id="<?php echo e($elId($code)); ?>" <?php endif; ?> value="<?php echo e($val); ?>" data-lt-input>
            <?php endif; ?>
        </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    <?php if($help): ?><small class="lt-help"><?php echo e($help); ?></small><?php endif; ?>
</div>

<?php if (! $__env->hasRenderedOnce('fcbb8ba2-a703-4fc0-8747-df5df3975785')): $__env->markAsRenderedOnce('fcbb8ba2-a703-4fc0-8747-df5df3975785'); ?>
<style>
.lt{margin-bottom:14px}
.lt-label{font-weight:600;margin-bottom:6px}
.lt-bar{display:inline-flex;border:1px solid var(--ln,#e2e8f0);border-radius:99px;padding:3px;margin-bottom:8px;background:#fff}
.lt-tab{position:relative;border:0;background:none;color:var(--tx,#0f172a);padding:5px 16px;border-radius:99px;font-weight:600;cursor:pointer;font-family:inherit}
.lt-tab.on{background:var(--pr,#3b82f6);color:#fff}
.lt-dot{position:absolute;top:4px;right:6px;width:7px;height:7px;border-radius:50%;background:#f59e0b}
.lt-pane{display:none}.lt-pane.on{display:block}
.lt-pane input,.lt-pane textarea{margin-top:0!important}
.lt-help{display:block;color:var(--mu,#64748b);margin-top:4px;font-size:13px}
</style>
<script>
document.addEventListener('DOMContentLoaded', function () {
  document.querySelectorAll('[data-lt]').forEach(function (box) {
    var tabs = [].slice.call(box.querySelectorAll('[data-lt-tab]'));
    var panes = [].slice.call(box.querySelectorAll('[data-lt-pane]'));
    function mark() {
      panes.forEach(function (p) {
        var code = p.getAttribute('data-lt-pane'), inp = p.querySelector('[data-lt-input]');
        var tab = tabs.filter(function (t) { return t.getAttribute('data-lt-tab') === code; })[0];
        if (tab) tab.querySelector('.lt-dot').hidden = !!(inp && inp.value.trim() !== '');
      });
    }
    tabs.forEach(function (t) {
      t.addEventListener('click', function () {
        var c = t.getAttribute('data-lt-tab');
        tabs.forEach(function (x) { x.classList.toggle('on', x === t); });
        panes.forEach(function (p) { p.classList.toggle('on', p.getAttribute('data-lt-pane') === c); });
      });
    });
    box.addEventListener('input', mark);
    mark();
  });
});
</script>
<?php endif; ?>
<?php /**PATH E:\newarmada\companyprofile\ComprofArmada\resources\views/components/lang-tabs.blade.php ENDPATH**/ ?>