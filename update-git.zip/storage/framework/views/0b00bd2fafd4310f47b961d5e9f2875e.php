<?php $__env->startSection('title', $news->tr('title') . ' – New Armada'); ?>

<?php $__env->startSection('content'); ?>
<section class="ah">
    <div class="ah-bg" <?php if($news->thumbnail_url): ?> style="background-image:url('<?php echo e($news->thumbnail_url); ?>')" <?php endif; ?>></div>
    <div class="wrap">
        <a class="back" href="<?php echo e(route('news.index')); ?>"><?php echo e(__('site.back_all_news')); ?></a>
        <span class="nh-tag"><?php echo e($news->category); ?></span>
        <h1><?php echo e($news->tr('title')); ?></h1>
        <div class="nh-date"><?php echo e($news->dateLabel()); ?></div>
    </div>
</section>

<section class="art">
    <div class="wrap">
        <div class="art-body">
            <?php $__empty_1 = true; $__currentLoopData = $news->blocks ?? []; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $b): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <?php if(($b['type'] ?? 'p') === 'i'): ?>
                    <?php $src = \App\Models\News::fileUrl($b['image'] ?? null); $cap = $news->localized($b['caption'] ?? []); ?>
                    <?php if($src): ?>
                        <figure>
                            <img src="<?php echo e($src); ?>" alt="<?php echo e($cap); ?>" loading="lazy" onerror="this.closest('figure').remove()">
                            <?php if($cap !== ''): ?><figcaption><?php echo e($cap); ?></figcaption><?php endif; ?>
                        </figure>
                    <?php endif; ?>
                <?php else: ?>
                    <?php $txt = $news->localized($b['text'] ?? []); ?>
                    <?php if($txt !== ''): ?><p><?php echo nl2br(e($txt)); ?></p><?php endif; ?>
                <?php endif; ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <p><?php echo e(__('site.news_empty')); ?></p>
            <?php endif; ?>
        </div>
    </div>
</section>

<?php if($others->isNotEmpty()): ?>
<section class="all-news">
    <div class="wrap">
        <div class="sec-head"><div><h2><?php echo e(__('site.more_news')); ?></h2></div>
            <a class="btn btn-red" href="<?php echo e(route('news.index')); ?>"><?php echo e(__('site.see_all')); ?></a>
        </div>
        <div class="news-grid">
            <?php $__currentLoopData = $others; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $n): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php echo $__env->make('news._card', ['n' => $n], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    </div>
</section>
<?php endif; ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('news.layout', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH E:\newarmada\companyprofile\ComprofArmada\resources\views/news/show.blade.php ENDPATH**/ ?>