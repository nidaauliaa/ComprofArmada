
<?php
    $footCats = collect();
    try { $footCats = \App\Models\Category::where('is_active', true)->orderBy('sort_order')->orderBy('id')->get(); } catch (\Throwable $e) {}
    $socials = ['instagram' => 'Instagram', 'facebook' => 'Facebook', 'youtube' => 'YouTube', 'tiktok' => 'TikTok', 'linkedin' => 'LinkedIn'];
    $shown = 0;
?>
<footer>
  <div class="wrap">
    <div class="footer-grid">
      <div>
        <a class="logo" href="<?php echo e(url('/')); ?>" style="color:#fff">
          <?php if(!empty($site['logo'])): ?><img src="<?php echo e(asset('storage/'.$site['logo'])); ?>" alt="<?php echo e($site['site_name'] ?? 'New Armada'); ?>" style="height:34px;width:auto;display:block"><?php else: ?><span class="logo-icon"></span>NEW ARMADA <?php endif; ?>
        </a>
        <p style="max-width:32ch;margin-top:12px;font-size:15px"><?php echo e(__('site.footer_tagline')); ?></p>
        <?php if(!empty($site['address'])): ?><p style="max-width:34ch;font-size:14px;margin:6px 0"><?php echo e($site['address']); ?></p><?php endif; ?>
        <?php if(!empty($site['phone'])): ?><p style="font-size:14px;margin:4px 0"><?php echo e($site['phone']); ?></p><?php endif; ?>
        <?php if(!empty($site['email_marketing'])): ?><p style="font-size:14px;margin:4px 0"><a href="mailto:<?php echo e($site['email_marketing']); ?>"><?php echo e($site['email_marketing']); ?></a></p><?php endif; ?>
      </div>
      <div><h4><?php echo e(__('site.products')); ?></h4><ul>
        <?php $__currentLoopData = $footCats; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $fc): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          <li><a href="<?php echo e(route('product.index', ['kategori' => $fc->slug])); ?>"><?php echo e($fc->t('name')); ?></a></li>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
      </ul></div>
      <div><h4><?php echo e(__('site.company')); ?></h4><ul>
        <li><a href="<?php echo e(url('/')); ?>#unit"><?php echo e(__('site.business_unit')); ?></a></li>
        <li><a href="<?php echo e(url('/')); ?>#plant"><?php echo e(__('site.plant_locations')); ?></a></li>
        <li><a href="<?php echo e(route('news.index')); ?>"><?php echo e(__('site.news')); ?></a></li>
        <li><a href="<?php echo e(url('/')); ?>#sosmed"><?php echo e(__('site.social_media')); ?></a></li>
        <li><a href="<?php echo e(url('/kontak')); ?>"><?php echo e(__('site.contact_us')); ?></a></li>
      </ul></div>
      <div><h4><?php echo e(__('site.follow_us')); ?></h4><ul>
        <?php $__currentLoopData = $socials; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $label): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          <?php if(!empty($site['social_'.$key])): ?>
            <?php $shown++; ?>
            <li><a href="<?php echo e($site['social_'.$key]); ?>" target="_blank" rel="noopener"><?php echo e($label); ?></a></li>
          <?php endif; ?>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <?php if($shown === 0): ?><li><a href="https://instagram.com/newarmada.official" target="_blank" rel="noopener">Instagram</a></li><?php endif; ?>
      </ul></div>
    </div>
    <div class="footer-bottom"><span>© <?php echo e(date('Y')); ?> <?php echo e($site['site_name'] ?? 'New Armada'); ?>. <?php echo e(__('site.rights')); ?></span><span>Company Profile Redesign</span></div>
  </div>
</footer>
<?php /**PATH E:\newarmada\companyprofile\ComprofArmada\resources\views/partials/public-footer.blade.php ENDPATH**/ ?>