<?php $__env->startSection('title', 'Berita – New Armada'); ?>

<?php $__env->startSection('content'); ?>
<?php if($latest->isEmpty()): ?>
    <section class="nh">
        <div class="wrap nh-grid" style="grid-template-columns:1fr">
            <div class="nh-main">
                <span class="nh-tag"><?php echo e(__('site.news')); ?></span>
                <h1><?php echo e(__('site.no_news_title')); ?></h1>
                <p class="desc"><?php echo e(__('site.no_news_sub')); ?></p>
            </div>
        </div>
    </section>
<?php else: ?>
    <?php $first = $latest->first(); ?>

    
    <section class="nh" id="nh">
        <div class="nh-bg" id="nhBg"
             <?php if($first->thumbnail_url): ?> style="background-image:url('<?php echo e($first->thumbnail_url); ?>')" <?php endif; ?>></div>

        <div class="wrap nh-grid">
            <div class="nh-main">
                <span class="nh-tag" id="nhTag"><?php echo e(__('site.latest')); ?></span>
                <h1 id="nhTitle"><?php echo e($first->tr('title')); ?></h1>
                <p class="desc" id="nhDesc"><?php echo e($first->summary(220)); ?></p>
                <div class="nh-date" id="nhDate"><?php echo e($first->dateLabel()); ?></div>
                <a class="btn" id="nhLink" href="<?php echo e(route('news.show', $first->slug)); ?>"><?php echo e(__('site.read_more')); ?> →</a>

                <?php if($popular->isNotEmpty()): ?>
                    <div class="nh-trend">
                        <h4 class="nh-label">
                            <svg viewBox="0 0 24 24"><path d="M3 17l6-6 4 4 8-8"/><path d="M15 7h6v6"/></svg><?php echo e(__('site.popular')); ?>

                        </h4>
                        <div class="nh-trend-row">
                            <?php $__currentLoopData = $popular; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $n): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <button type="button" class="t-card" data-pick="<?php echo e($n->id); ?>">
                                    <span class="th">
                                        <?php if($n->thumbnail_url): ?><img src="<?php echo e($n->thumbnail_url); ?>" alt="" loading="lazy" onerror="this.remove()"><?php endif; ?>
                                    </span>
                                    <h5><?php echo e($n->tr('title')); ?></h5>
                                </button>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div>
                    </div>
                <?php endif; ?>
            </div>

            <aside class="nh-side">
                <h4 class="nh-label">
                    <svg viewBox="0 0 24 24"><path d="M4 10v4l12 5V5z"/><path d="M16 9a4 4 0 0 1 0 6"/></svg><?php echo e(__('site.latest_news')); ?>

                </h4>
                <div id="nhSide">
                    <?php $__currentLoopData = $latest; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $n): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <button type="button" class="s-item <?php echo e($loop->first ? 'current' : ''); ?>" data-pick="<?php echo e($n->id); ?>">
                            <span class="th">
                                <?php if($n->thumbnail_url): ?><img src="<?php echo e($n->thumbnail_url); ?>" alt="" loading="lazy" onerror="this.remove()"><?php endif; ?>
                            </span>
                            <span>
                                <h5><?php echo e($n->tr('title')); ?></h5>
                                <small><?php echo e($n->dateLabel()); ?></small>
                            </span>
                        </button>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            </aside>
        </div>
    </section>
<?php endif; ?>


<section class="all-news" id="semua">
    <div class="wrap">
        <div class="sec-head">
            <div><h2><?php echo e(__('site.all_news')); ?></h2></div>
            <p><?php echo e(__('site.all_news_sub')); ?></p>
        </div>

        <?php if($all->isEmpty()): ?>
            <p style="color:var(--ink-muted)"><?php echo e(__('site.no_news')); ?></p>
        <?php else: ?>
            <div class="news-grid">
                <?php $__currentLoopData = $all; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $n): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php echo $__env->make('news._card', ['n' => $n], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>

            <?php if($all->hasPages()): ?>
                <div class="pg">
                    <?php if($all->onFirstPage()): ?>
                        <span class="dis"><?php echo e(__('site.prev_page')); ?></span>
                    <?php else: ?>
                        <a href="<?php echo e($all->previousPageUrl()); ?>"><?php echo e(__('site.prev_page')); ?></a>
                    <?php endif; ?>
                    <span class="pg-i"><?php echo e(__('site.page_of', ['current' => $all->currentPage(), 'last' => $all->lastPage()])); ?></span>
                    <?php if($all->hasMorePages()): ?>
                        <a href="<?php echo e($all->nextPageUrl()); ?>"><?php echo e(__('site.next_page')); ?></a>
                    <?php else: ?>
                        <span class="dis"><?php echo e(__('site.next_page')); ?></span>
                    <?php endif; ?>
                </div>
            <?php endif; ?>
        <?php endif; ?>
    </div>
</section>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('scripts'); ?>
<?php if($latest->isNotEmpty()): ?>
<script>
(function () {
  var D = <?php echo json_encode((object) $heroItems->all(), 15, 512) ?>, FIRST = <?php echo json_encode($first->id, 15, 512) ?>;
  var $ = function (id) { return document.getElementById(id); };

  function pick(id) {
    var n = D[id]; if (!n) return;
    var bg = $('nhBg');
    bg.style.backgroundImage = n.img ? 'url("' + n.img + '")' : 'none';
    bg.classList.remove('anim'); void bg.offsetWidth; bg.classList.add('anim');
    $('nhTag').textContent = (n.id === FIRST) ? 'Terbaru' : n.tag;
    $('nhTitle').textContent = n.title;
    $('nhDesc').textContent = n.desc;
    $('nhDate').textContent = n.date;
    $('nhLink').href = n.url;
    [].forEach.call(document.querySelectorAll('#nhSide .s-item'), function (b) {
      b.classList.toggle('current', Number(b.dataset.pick) === Number(id));
    });
    if (window.innerWidth <= 1000) $('nh').scrollIntoView({ behavior: 'smooth' });
  }

  document.addEventListener('click', function (e) {
    var b = e.target.closest('[data-pick]');
    if (b) pick(b.dataset.pick);
  });
})();
</script>
<?php endif; ?>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('news.layout', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH E:\newarmada\companyprofile\ComprofArmada\resources\views/news/index.blade.php ENDPATH**/ ?>