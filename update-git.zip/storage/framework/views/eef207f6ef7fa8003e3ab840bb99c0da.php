<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, viewport-fit=cover">
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
    <title><?php echo $__env->yieldContent('title', 'Panel Admin'); ?> – New Armada</title>
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link href="https://fonts.googleapis.com/css2?family=Barlow+Condensed:wght@600;700;800&family=Barlow:wght@400;500;600;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="<?php echo e(asset('css/admin.css')); ?>?v=<?php echo e(@filemtime(public_path('css/admin.css'))); ?>">
    <?php echo $__env->yieldPushContent('styles'); ?>
</head>
<body>
    <?php echo $__env->make('layouts.partials.icons', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

    <div class="ap" id="ap">
        <?php echo $__env->make('layouts.admin-sidebar', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

        <div class="amw">
            <div class="at">
                <button type="button" class="b o s" id="tg" aria-label="Buka atau tutup menu"><svg class="i"><use href="#i-panel"/></svg></button>
                <svg class="i" style="width:18px;height:18px"><use href="#i-<?php echo e(trim($__env->yieldContent('page_icon')) ?: 'home'); ?>"/></svg>
                <b><?php echo $__env->yieldContent('page_title', 'Beranda'); ?></b>
                <span class="sp"></span>
                <span class="usr"><svg class="i"><use href="#i-user"/></svg> <?php echo e(Auth::user()->name ?? 'Tim Marketing New Armada'); ?></span>
                <form method="POST" action="<?php echo e(route('logout')); ?>">
                    <?php echo csrf_field(); ?>
                    <button type="submit" class="b o s"><svg class="i"><use href="#i-out"/></svg> Keluar</button>
                </form>
            </div>

            <div class="am">
                <?php if(session('success')): ?>
                    <div class="alert-success"><?php echo e(session('success')); ?></div>
                <?php endif; ?>

                <?php echo $__env->yieldContent('content'); ?>
            </div>
        </div>
    </div>

    <?php echo $__env->yieldPushContent('modals'); ?>

    <script>
        // Buka/tutup sidebar (desktop: ciut jadi ikon, HP: menu geser). Pilihan diingat.
        (function () {
            var ap = document.getElementById('ap'), key = 'na-side';
            try { if (innerWidth > 820 && localStorage.getItem(key) === '1') ap.classList.add('col'); } catch (e) {}
            document.getElementById('tg').addEventListener('click', function () {
                if (innerWidth <= 820) { ap.classList.toggle('mo'); return; }
                ap.classList.toggle('col');
                try { localStorage.setItem(key, ap.classList.contains('col') ? '1' : '0'); } catch (e) {}
            });
        })();
    </script>
    <?php echo $__env->yieldPushContent('scripts'); ?>
</body>
</html>
<?php /**PATH E:\newarmada\companyprofile\ComprofArmada\resources\views/layouts/admin.blade.php ENDPATH**/ ?>