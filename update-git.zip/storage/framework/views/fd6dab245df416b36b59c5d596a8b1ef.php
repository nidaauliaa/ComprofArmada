<?php
    $cur = app()->getLocale();
    $locales = config('site.locales');
    $short = fn ($c) => $c === 'zh' ? '中文' : strtoupper($c);
?>
<div class="lang-wrap" data-lang-wrap>
    <button type="button" class="lang" data-lang-btn aria-haspopup="true" aria-expanded="false" aria-label="<?php echo e(__('site.language')); ?>"><?php echo e($short($cur)); ?> ▾</button>
    <div class="lang-menu">
        <?php $__currentLoopData = $locales; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $code => $name): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <a href="<?php echo e(route('lang.switch', $code)); ?>" hreflang="<?php echo e($code); ?>" class="<?php echo e($code === $cur ? 'on' : ''); ?>"><?php echo e($name); ?></a>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
</div>
<?php /**PATH E:\newarmada\companyprofile\ComprofArmada\resources\views/components/lang-switcher.blade.php ENDPATH**/ ?>